//Prashant Mittal
//2020CSB1113

//Including the libraries required
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

int m; // size of the hash-table

// Structure of the node in the hash-table
struct Node
{
    int key;           // varibale to store the key in the node of the hash-table
    struct Node *prev; // to store the address of the previous node
    struct Node *next; // to store the address of the next node
};

typedef struct Node node; // Renaming structure for simplicity

node **table; // Hash-table

// Function to insert the value in hash-table
void insert(int k)
{
    int index = k % m;                         // Finding out the index where the key has to be stored
    index = (index + m) % m;                   // If key is negative then we take care of that condition by adding m into that
    node *head = (node *)malloc(sizeof(node)); // Allocating memory to the node which has to be the head of the doubly linked list at a particular index
    head->key = k;                             // Initialise the value to be inserted into the key of the node
    head->next = table[index];                 // Next of the node has to be the current head of the doubly-linked list
    head->prev = NULL;                         // Prev of the node has to be NULL since it is the head now
    if (table[index] != NULL)
    {
        table[index]->prev = head; // If table isn't null then the current head's prev corresponds to the new head of the doubly linked list
    }
    table[index] = head; // Initialize the new head of the doubly-linked list
    // Can't free the head node otherwise data would be erased, sorry
}

// Function to delete the element from the hash-table
void delete (int k)
{
    int index = k % m;         // Finding out the index where the key has to be stored
    index = (index + m) % m;   // If key is negative then we take care of that condition by adding m into that
    node *head = table[index]; // Initialize the variable with the head of the doublt-linked list of a particular index
    while (head != NULL)       // Until it reaches the end of the doubly-linked list or if it is null
    {
        if (head->key == k) // If we've found the key in the doubly-linked list
        {
            if (head->prev == NULL && head->next == NULL)
            {
                table[index] = NULL; // If it is the only element in the doubly-linked list then the list becomes empty arfter deleting that element
            }
            else if (head->prev == NULL)
            {
                head->next->prev = NULL;   // If it is the first element then prev of next corresponds to NULL
                table[index] = head->next; // Head of the list becomes the next node to it
            }
            else if (head->next == NULL)
            {
                head->prev->next = NULL; // If it is the last element of the list then next of prev corresponds to NULL
            }
            else
            {
                head->prev->next = head->next; // If above all are not the case then simply remove it from the between of the prev and next nodes
                head->next->prev = head->prev; // The next of the node before the current node corresponds to the next node, and prev of the node after the current node corresponds to the prev node
            }
            free(head); // Freeing the node this time
            return;
        }
        head = head->next; // If the current element is not equal to the element to be deleted then we move onto next element
    }
    printf("No such element exists\n"); // If above it wasn't returned that means key is not present
}

//Function to search for a key inside the hash table
void search(int k)
{
    int index = k % m;         // Finding out the index where the key has to be stored
    index = (index + m) % m;   // If key is negative then we take care of that condition by adding m into that
    node *head = table[index]; // Initialize the variable with the head of the doublt-linked list of a particular index
    while (head != NULL)       // Until we reach the end of the linked list the loop moves on
    {
        if (head->key == k)
        {
            printf("Searched element found in slot number %d\n", index); // If at some point the key is found then we return
            return;
        }
        head = head->next; // If not found then move onto next element
    }
    printf("Searched element not found\n"); // If not returned above that means key is not found
    free(head);                             // Freeing the head which is NULL itself
}

void display()
{
    for (int i = 0; i < m; i++) // Loop for accessing all the lists inside the hash-table
    {
        printf("Index %d : ", i); // Printing Index i where i is current slot
        if (table[i] == NULL)
        {
            printf("NULL\n"); // If the list is empty then we print NULL
        }
        else
        {
            node *head = table[i]; // Initialize the variable with the head of the doublt-linked list of a particular index
            while (head != NULL)   // Traversing through the whole list
            {
                printf("%d ", head->key); // Printing the value in current node of the list
                head = head->next;        // Moving onto the next node in the list
            }
            printf("\n"); // Printing a new line
            free(head);   // Freeing the head which is NULL itself
        }
    }
}

// Main Function
int main()
{
    printf("Enter hash table size m: "); // Asking user to input the size of the hash-table
    scanf("%d", &m);                     // Taking the input for hash0table size
    while (m <= 0)                       // If size is less than or equals 0 then ask again for input of the size
    {
        printf("Come on, can size of hash-table be that!\n"); // Telling user that size can't be which he/she has entered
        printf("Enter hash table size m: ");                  // Again asking for the input of size
        scanf("%d", &m);                                      // Taking in the size of the hash-table
    }
    table = (node **)malloc(m * sizeof(node)); //Allocating memory for m size hash-table
    for (int i = 0; i < m; i++)
    {
        table[i] = NULL; // Initialize the doubly-linked list for every index as NULL at first
    }
    printf("1. Insert\n");
    printf("2. Delete\n");
    printf("3. Search\n");
    printf("4. Display\n");
    printf("5. Quit\n");
    printf("Enter your choice : "); // Asking user for the function he/she wants to perform
    char c;                         // Declared variable to store the input given by the user
    scanf(" %c", &c);               // Taking in the input for the type of function in the list printed above
    while (c != '5')                // If c is 5 then Quit else execute the below loop
    {
        if (c == '1') // If chosen function is 1
        {
            printf("Enter value to insert : "); // Asking for the value to be inserted
            int n;                              // Variable to store the key to be inserted
            scanf("%d", &n);                    // Taking input of the element to be stored
            insert(n);                          // Calling insert function
        }
        else if (c == '2') // If chosen function is 2
        {
            printf("Enter value to delete : "); // Asking the user value to be deleted
            int n;                              // Variable to store the value that has to be deleted
            scanf("%d", &n);                    // Taking input for the element to be deleted
            delete (n);                         // Calling delete function
        }
        else if (c == '3') // If chosen function is 3
        {
            printf("Enter the element to be searched : "); // Asking user for the element to be searched
            int n;                                         // Varibale to store the value that has to be searched
            scanf("%d", &n);                               // Taking input for the value that has to be searched
            search(n);                                     // Calling the search function
        }
        else if (c == '4') // If chosen function is 5
        {
            display(); // Calling display funciton to display the hash-table
        }
        else
        {
            printf("Unknown Command!\n"); // If chosen type is outside the list of available functions then it is an invalid command
        }
        printf("1. Insert\n");
        printf("2. Delete\n");
        printf("3. Search\n");
        printf("4. Display\n");
        printf("5. Quit\n");            // Printing again the list of operations that can be performed
        printf("Enter your choice : "); // Asking again which operation to be performed
        scanf(" %c", &c);               // Taking in the type of function to be called
    }
    free(table); // After we've done everything we clear the hash-table which is very very necessary
    return 0;
}