#include<stdio.h>
int main(){
    int m=50 % 12;
    printf("%d",m );
}