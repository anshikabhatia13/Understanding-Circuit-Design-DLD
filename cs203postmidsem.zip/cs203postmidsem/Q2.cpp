#include <bits/stdc++.h>
using namespace std;
vector<string> a;
vector<string> b;
vector<bool> trackRecord;
vector<string> bitmin;
vector<string> intmin;
vector<string> dominatingRowsInBits;
map<string, bool> ocuuredminterm;
vector<string> essentialPrimeImplicantsInBits;
string cbits(int minTerm);
string cstring(int num);
bool checkdiff(string s1, string s2);
string EditByteString(string s1, string s2);
void MakeTable(int start);
void ImplicantTable();
void EssentialPrimeImplicants();
void RemoveDominatedRows();
void PrintFinalResult(int numberOfBits);
int n1;
bool arr[50][50];
int pf[50] = {0};
int main()
{

    int numberOfBits;
    cout<<" ! This program takes number of bits(variables) and then enter the number of minterms with 1 value in K map. then add those specific values\n "<<endl;
    cout<<"number of bits: ";
    cin >> numberOfBits;

    cout << "Enter the number of MinTerms: ";
    cin >> n1;

    int minTerms[n1];

    for (int i = 0; i < n1; i++)
    {
        cout << "Enter MinTerm: ";
        cin >> minTerms[i];
    }

    sort(minTerms, minTerms + n1); 
                                  
    for (int i = 0; i < n1; i++)
    {
        bitmin.push_back(cbits(minTerms[i]));
        intmin.push_back(cstring(minTerms[i]));
        trackRecord.push_back(false);
    }
    MakeTable(0);
    ImplicantTable();
    EssentialPrimeImplicants();
    RemoveDominatedRows(); 
    PrintFinalResult(numberOfBits);
    return (0);
}
string cbits(int minTerm)
{
    int num = minTerm;
    int index = 0;
    char bits[20];
    char r[20];
    for (int i = 0; i < 8; i++)
    {
        bits[i] = num % 2 + '0';
        num /= 2;
    }
    bits[8] = '\0';
    for (int i = 7; i >= 0; i--)
    {
        r[7 - i] = bits[i];
    }
    r[8] = '\0';
    string str = r;
    return str;
}

string cstring(int num)
{
    int res = num;
    int index = 0;
    char ch[4], rch[4];
    while (res)
    {
        ch[index] = res % 10 + '0';
        res /= 10;
        index++;
    }
    ch[index] = '\0';
    for (int i = index - 1; i >= 0; i--)
    {
        rch[index - 1 - i] = ch[i];
    }
    rch[index] = '\0';
    if (num == 0)
    {
        rch[0] = '0';
        rch[1] = '\0';
    }
    string str = rch;
    return str;
}

bool checkdiff(string s1, string s2)
{ // Checks for one bit difference between two given bit strings
    int count = 0;
    for (int i = 0; i < 8; i++)
    {
        if (s1[i] != s2[i])
        {
            count++;
        }
    }
    return (count == 1);
}

string EditByteString(string s1, string s2)
{ // Returns a string with '-' in the different bit
    string res = s1;
    for (int i = 0; i < 8; i++)
    {
        if (s1[i] != s2[i])
        {
            res[i] = '-';
        }
    }
    return res;
}

void MakeTable(int start)
{ // Generates the MinTerm Table recursively
    bool toRepeat = false;
    int len = bitmin.size();
    for (int i = start; i < len - 1; i++)
    {
        for (int j = i + 1; j < len; j++)
        {
            if (checkdiff(bitmin[i], bitmin[j]))
            {
                trackRecord[i] = true;
                trackRecord[j] = true;
                if (!ocuuredminterm[EditByteString(bitmin[i], bitmin[j])])
                {
                    intmin.push_back(intmin[i] + "," + intmin[j]);
                    bitmin.push_back(EditByteString(bitmin[i], bitmin[j]));
                    ocuuredminterm[EditByteString(bitmin[i], bitmin[j])] = true;
                    toRepeat = true;
                }
            }
        }
    }
    if (!toRepeat)
    {
        return;
    }
    else
    {
        MakeTable(len);
    }
}

// void Print(){
// 	int len = bitmin.size();
// 	for (int i=0 ; i<len ; i++){
// 		cout << intmin[i] << "\t\t" << bitmin[i] << "\t" << trackRecord[i] << "\n";
// 	}
// 	//cout << intmin.size() << bitmin.size() << trackRecord.size();		#Test
// }

void ImplicantTable()
{
    int len = intmin.size();
    for (int i = 0; i < len; i++)
    {
        if (!trackRecord[i])
        {
            b.push_back(intmin[i]);
            a.push_back(bitmin[i]);
        }
    }

    len = b.size();
    for (int i = 0; i < len; i++)
    {
        for (int j = 0; j < n1; j++)
        {
            arr[i][j] = false;
            char temp1[30], temp2[10];
            strcpy(temp1, b[i].c_str());
            strcpy(temp2, intmin[j].c_str());
            char *ptr = strstr(temp1, temp2);
            if (ptr && (temp1[ptr - temp1 + strlen(temp2)] == ',' || temp1[ptr - temp1 + strlen(temp2)] == '\0'))
            {
                arr[i][j] = true;
            }
        }
    }
}

void EssentialPrimeImplicants()
{
    int len = b.size();
    int count = 0;
    int index = -1;
    for (int i = 0; i < n1; i++)
    {
        count = 0;
        for (int j = 0; j < len; j++)
        {
            if (arr[j][i])
            {
                count++;
                index = j;
            }
        }
        if (count == 1)
        {
            essentialPrimeImplicantsInBits.push_back(a[index]);
            pf[index] = 1;
            for (int k = 0; k < n1; k++)
            {
                if (arr[index][k])
                {
                    for (int l = 0; l < len; l++)
                    {
                        arr[l][k] = false;
                    }
                }
            }
        }
    }
}

void RemoveDominatedRows()
{
    int len = b.size();
    bool dominated = true;
    bool rDominated = true;
    for (int i = 0; i < len; i++)
    {
        for (int j = 0; j < len; j++)
        {
            if (pf[j] == 0)
            {
                dominated = true;
                rDominated = true;
                if (i != j)
                {
                    for (int k = 0; k < n1; k++)
                    {
                        if (arr[j][k] != arr[i][k])
                        {
                            rDominated = false;
                        }
                        if (arr[j][k] == 1 && arr[i][k] != 1)
                        {
                            dominated = false;
                            break;
                        }
                    }
                    if (dominated && pf[j] == 0)
                    {
                        pf[j] = -1;
                    }
                    if (rDominated)
                    {
                        pf[i] = 2;
                    }
                }
            }
        }
    }
}
void PrintFinalResult(int numberOfBits)
{
    int len = b.size();
    char ch = 'A';
    for (int i = 0; i < len; i++)
    {
        if (pf[i] != -1)
        { // Prints the final human readable result
            ch = 'A';
            for (int j = 8 - numberOfBits; j < 8; j++)
            {
                if (a[i][j] == '0')
                {
                    cout << ch << "'";
                }
                if (a[i][j] == '1')
                {
                    cout << ch;
                }
                ch++;
            }
            cout << " + ";
        }
    }
    cout << "\n";
}