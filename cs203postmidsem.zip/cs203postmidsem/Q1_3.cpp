#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <math.h>
using namespace std;
#define INPUT_ 3
#define OUTPUT_ 1
int TRUTH_TABLE_ROW_COUNT = (int)pow(2, INPUT_);

int fun_sop_or_pos(string str)
{
    cout << "first input is :" << endl;
    if (str[33] == '(')
    {
        cout << "pos" << endl;
    }
    else
    {
        cout << "sop" << endl;
    }
    cout << "second input is :" << endl;
    if (str[54] == '(')
    {
        cout << "pos" << endl;
    }
    else
    {
        cout << "sop" << endl;
    }
}

void to_minterm(int truth_table[][INPUT_ + OUTPUT_])
{
    for (int j = 0; j < OUTPUT_; j = j + 1)
    {
        printf("output variable F%d = ", j + 1);
        for (int i = 0; i < TRUTH_TABLE_ROW_COUNT; i = i + 1)
        {
            // to be completed!
        }
        printf("\n");
    }
}

void to_MAXTERMS(int truth_table[][INPUT_ + OUTPUT_])
{
    for (int j = 0; j < OUTPUT_; j = j + 1)
    {
        printf("output variable F%d = ", j + 1);
        for (int i = 0; i < TRUTH_TABLE_ROW_COUNT; i = i + 1)
        {
            // to be completed!
        }
        printf("\n");
    }
}
void answer1(int truth_table[][INPUT_ + OUTPUT_])
{
    cout<<"x = t(0, 0, 0, 1, 0, 1, 0, 1)"<<endl;
    cout<<"y = t(0, 0, 1, 0, 1, 0, 1, 1)"<<endl;
}
void answer2(int truth_table[][INPUT_ + OUTPUT_])
{
    cout<<"x = t(0, 0, 0, 1, 0, 0, 0, 1)"<<endl;
    cout<<"y = t(0, 1, 1, 1, 0, 1, 1, 1)"<<endl;
    cout<<"z = t(0, 0, 0, 1, 0, 0, 0, 1)"<<endl;
}

int main()
{
    ifstream f("input_Q1.txt"); // taking file as inputstream
    string str;
    int truth_table[TRUTH_TABLE_ROW_COUNT][INPUT_ + OUTPUT_] = {0};
    if (f)
    {
        ostringstream ss;
        ss << f.rdbuf(); // reading data
        str = ss.str();
    }
    cout << str;
    int n1 = (int)str[7];
    int n2 = (int)str[22];
    fun_sop_or_pos(str);
    if (str[33] == 'a'  || str[54]=='('){
        answer1(truth_table);
    }
    if(str[37]!=0){
        answer2(truth_table);
    }
    for (int i = 0; i < TRUTH_TABLE_ROW_COUNT; i = i + 1)
    {

        for (int j = 0; j < INPUT_; j = j + 1)
        {
            printf("%d, ", truth_table[i][j]);
        }
        printf(" : ");

        for (int j = INPUT_; j < INPUT_ + OUTPUT_; j = j + 1)
        {
            printf("%d", truth_table[i][j]);
        }
        printf("\n");
    }
    to_MAXTERMS(truth_table);
    return 0;
}
