//ANSHIKA 2021CSB1069
//declaring libraries
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
// making a node
struct node
{
    int key;// data that the node stores
    struct node *prev;//pointer to the previous node 
    struct node *next;//pointer to the next node
} * *hash_table;

int m;// global declaration of hash table size
void insert(int key);// function for insertion

void delete (int key);// function for deletion

void search(int key);// function for searching

void display();// function for displaying

int hashing(int key);// function for hashing by division method

int main()
{
    int choice;

    printf("Enter hash table size m:\n");

    scanf("%d", &m);// taking input of hash table size

    hash_table = (struct node **)malloc(m * sizeof(struct node));// dynamically allocting memory to the pointer to a pointer hash table
    for (int i = 0; i < m; i++)
    {
        hash_table[i] = NULL;// all indices initialised to null
    }
    printf("1. Insert\n2. Delete\n3. Search\n4. Display\n5. Quit\nEnter your choice:");

    scanf("%d", &choice);//taking input of the choice
    while (choice != 5)
    {
        if (choice == 1)// for insertion
        {
            int value;
            printf("Enter value to insert:\n");
            scanf("%d", &value);//taking input of value to be inserted
            insert(value);// calling insert function
        }

        else if (choice == 2)// for deletiom
        {
            int value;
            printf("Enter the value to delete:\n");
            scanf("%d", &value);//taking input of value to be deleted
            delete (value);//caliing delete function
        }
        else if (choice == 3)// for searching
        {
            int element;
            printf("Enter the element to be searched:\n");
            scanf("%d", &element);//taking input of value to be searched
            search(element);//calling search function
        }
        else if (choice == 4)// for displaying the hash table
        {
            display();
        }
        else
            printf("invalid command!\n");
        printf("1. Insert\n2. Delete\n3. Search\n4. Display\n5. Quit\nEnter your choice:");
        scanf("%d", &choice);
    }
}
int hashing(int key)
{
    return key % m;// the division method
}
void insert(int key)
{
    int i = hashing(key);// getting the slot index
    i = (i + m) % m;// for negative cases 
    struct node *head = (struct node *)malloc(sizeof(struct node));// dyamically allocating memory for head
    head->key = key;// inserting the value in the key attribute of the head
    head->next = hash_table[i];// points to the next index of the hash table
    head->prev = NULL;// previou null
    if (hash_table[i] != NULL)// if there already is an element in that index
    {
        hash_table[i]->prev = head;// previous of that index of hash table points to head
    }
    hash_table[i] = head;
}
void delete (int key)
{
    int i = hashing(key);// getting the slot index
    i = (i + m) % m;// for negative cases
    struct node *head = hash_table[i];//initailize the variab;e with head of the doubly linked list for ith index
    while (head != NULL)
    {
        if (head->key == key)//if  key found
        {
            if (head->prev == NULL && head->next == NULL)
            {
                hash_table[i] = NULL;// singe element in the double linled list
            }
            else if (head->next == NULL)//last elemnt in the list
            {
                head->prev->next = NULL;
            }
            else if (head->prev == NULL)// first element in the list
            {
                head->next->prev = NULL;
                hash_table[i] = head->next;
            }

            else// otherwise simply remove the key
            {
                head->prev->next = head->next;
                head->next->prev = head->prev;
            }
            free(head);// freeing the node
            return;
        }
        head = head->next;// move to next if key not found 
    }
    printf("No such element exists\n");
}
void search(int key)
{
    int i = hashing(key);// getting the slot index
    i = (i + m) % m;// for negative cases
    struct node *head = hash_table[i];////initailize the variab;e with head of the doubly linked list for ith index
    while (head != NULL)// traversing the list
    {
        if (head->key == key)// if element to be searched is found
        {
            printf("Searched element found in slot number %d\n", i);
            return;
        }
        head = head->next;// if not found move onto the next
    }
    printf("Searched element is not found in the hash table\n");
    free(head);
}

void display()
{
    for (int i = 0; i < m; i++)// to access elements inside the hash table
    {
        printf("Index %d : ", i);// the index of the current slot
        if (hash_table[i] == NULL)
        {
            printf("NULL\n");//id linked list is empty
        }
        else
        {
            struct node *head = hash_table[i];//initailize the variab;e with head of the doubly linked list for ith index
            while (head != NULL)
            {
                printf("%d ", head->key);// printing the value in current node
                head = head->next;// moving onto next
            }
            printf("\n");
            free(head);// freeing head
        }
    }
}