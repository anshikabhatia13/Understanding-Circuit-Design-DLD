compile in terminal using the command gcc problem1.c
run using ./a.exe
