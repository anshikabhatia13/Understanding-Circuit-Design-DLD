#include<bits/stdc++.h>
#define askint(n) int n; cin>>n;
#define askstring(s) string s; cin>>s;
#define askarr(a,n) int a[n]; for(int i=0; i<n; i++) cin>>a[i];
#define showarr(a, n) for(int i=0; i<n ; i++) cout<<a[i]<<' '; cout <<endl;
#define foi(a,b) for(int i=a; i<b; i++)
#define foir(a,b) for(int i=a; i>=b; i--)
#define fojr(a,b) for(int j=a; j>=b; j--)
#define foj(a,b) for(int j=a; j<b; j++)
#define ll long long int 
using namespace std;

int main(){
    askint(t);
    while(t--){
        askint(n);
        askarr(a,n);
        askarr(b,n);
        if(n==1)
        {
            cout << a[0] << endl;
            continue;
        }
        ll sum=0,s=0;
        int max=0,temp=0;
        foi(0,n){
            sum += a[i];
            s+=b[i];
            if(max<b[i]){
            max=b[i];
            temp=i;}
        }
    cout << sum + s - b[temp] << endl;
    }
    return 0;
}